
import { Staff, KebeleService, MapLocation } from './types';

export const STAFF_LIST: Staff[] = [
  { 
    id: 's1', 
    name: 'Abebe Bikila', 
    role: 'Chief Administrator', 
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&h=200&fit=crop', 
    officeNumber: '101' 
  },
  { 
    id: 's2', 
    name: 'Tigist Assefa', 
    role: 'Vital Events Officer', 
    avatar: 'https://images.unsplash.com/photo-1531123897727-8f129e1688ce?q=80&w=200&h=200&fit=crop', 
    officeNumber: '204' 
  },
  { 
    id: 's3', 
    name: 'Selam Tsegaye', 
    role: 'Finance Officer', 
    avatar: 'https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?q=80&w=200&h=200&fit=crop', 
    officeNumber: '105' 
  },
  { 
    id: 's4', 
    name: 'Dawit Getachew', 
    role: 'Archive Specialist', 
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=200&h=200&fit=crop', 
    officeNumber: '002' 
  },
  { 
    id: 's5', 
    name: 'Mekdes Haile', 
    role: 'Front Desk Receptionist', 
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=200&h=200&fit=crop', 
    officeNumber: '001' 
  },
  { 
    id: 's6', 
    name: 'Kassa Tekle', 
    role: 'Security & Gate Keeper', 
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=200&h=200&fit=crop', 
    officeNumber: 'Gate A' 
  },
];

export const SERVICES: KebeleService[] = [
  {
    id: 'id-renew',
    title: 'Resident ID Renewal',
    description: 'Renewal of the neighborhood resident identity card for adults (18+).',
    requiredDocuments: [
      'Expired ID Card',
      '3 Passport size photos (recent)',
      'House ownership certificate or Rental agreement',
      'Support letter from workplace (if applicable)'
    ],
    processingTime: '2 - 3 Working Days',
    availableDays: 'Monday - Friday (8:30 AM - 5:30 PM)',
    steps: [
      { order: 1, description: 'Verify eligibility and pick up application form', officeId: 'o1', staffId: 's5', paymentAmount: 0 },
      { order: 2, description: 'Pay renewal fees at the finance window', officeId: 'o3', staffId: 's3', paymentAmount: 50 },
      { order: 3, description: 'Submit documents and get fingerprints taken', officeId: 'o2', staffId: 's2', paymentAmount: 0 },
      { order: 4, description: 'Final approval and card collection after 48 hours', officeId: 'o5', staffId: 's1', paymentAmount: 0 }
    ]
  },
  {
    id: 'birth-cert',
    title: 'Birth Certificate Registration',
    description: 'Official registration of new births within the Kebele jurisdiction.',
    requiredDocuments: [
      'Hospital Birth Notification',
      'Original IDs of both parents',
      '2 Witnesses with original IDs',
      'Marriage certificate (copy)'
    ],
    processingTime: 'Same Day',
    availableDays: 'Monday - Saturday',
    steps: [
      { order: 1, description: 'Information desk verification', officeId: 'o1', staffId: 's5', paymentAmount: 0 },
      { order: 2, description: 'Detailed registration with Vital Events Officer', officeId: 'o2', staffId: 's2', paymentAmount: 0 },
      { order: 3, description: 'Official stamp and certificate issuance', officeId: 'o5', staffId: 's1', paymentAmount: 25 }
    ]
  },
  {
    id: 'marriage-cert',
    title: 'Marriage Certificate Issuance',
    description: 'Legal registration and certification of civil marriages.',
    requiredDocuments: [
      'IDs of both spouses',
      '3 Witnesses with original IDs',
      '4 Passport photos each',
      'Eligibility letter from previous Kebele'
    ],
    processingTime: '3 Working Days',
    availableDays: 'Monday - Wednesday',
    steps: [
      { order: 1, description: 'Pre-marriage document verification', officeId: 'o2', staffId: 's2', paymentAmount: 0 },
      { order: 2, description: 'Fee processing for ceremony and certificate', officeId: 'o3', staffId: 's3', paymentAmount: 150 },
      { order: 3, description: 'Final signing and certification in Manager Office', officeId: 'o5', staffId: 's1', paymentAmount: 0 }
    ]
  },
  {
    id: 'land-transfer',
    title: 'Land Ownership Transfer',
    description: 'Documentation and verification for transferring property titles between individuals.',
    requiredDocuments: [
      'Original Title Deed',
      'Sales Agreement (Legalized)',
      'ID cards of Buyer and Seller',
      'Tax clearance certificate'
    ],
    processingTime: '15 - 20 Working Days',
    availableDays: 'Tuesdays and Thursdays',
    steps: [
      { order: 1, description: 'Initial file request and verification', officeId: 'o4', staffId: 's4', paymentAmount: 0 },
      { order: 2, description: 'Field measurement and site visit request', officeId: 'o5', staffId: 's1', paymentAmount: 200 },
      { order: 3, description: 'Tax evaluation and payment', officeId: 'o3', staffId: 's3', paymentAmount: 500 },
      { order: 4, description: 'Final deed issuance and registration', officeId: 'o2', staffId: 's2', paymentAmount: 0 }
    ]
  }
];

export const MAP_LOCATIONS: MapLocation[] = [
  { 
    id: 'o1', 
    name: 'Reception & Info', 
    type: 'office', 
    x: 40, y: 380, width: 120, height: 80, 
    description: 'Main Reception Area. A bright, open-plan modern office space designed for visitor comfort and efficient first-point contact.',
    imageUrl: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&h=500&fit=crop'
  },
  { 
    id: 'o2', 
    name: 'Vital Events Office', 
    type: 'office', 
    x: 260, y: 80, width: 160, height: 100, 
    description: 'Vital Records Room 204. Managed by Tigist Assefa. Professional document processing center for registrations.',
    imageUrl: 'https://images.unsplash.com/photo-1497215728101-856f4ea42174?w=800&h=500&fit=crop'
  },
  { 
    id: 'o3', 
    name: 'Finance Dept', 
    type: 'office', 
    x: 260, y: 380, width: 160, height: 80, 
    description: 'Finance & Payments Room 105. Professional financial hub where consultants review charts and process service payments.',
    imageUrl: 'https://images.unsplash.com/photo-1454165833767-02a6e3099033?w=800&h=500&fit=crop'
  },
  { 
    id: 'o4', 
    name: 'Archive Room', 
    type: 'office', 
    x: 40, y: 220, width: 100, height: 120, 
    description: 'Secure Archive Room 002. Organized storage of historical records and community data.',
    imageUrl: 'https://images.unsplash.com/photo-1568667256549-094345857637?w=800&h=500&fit=crop'
  },
  { 
    id: 'o5', 
    name: 'Chief Manager Office', 
    type: 'office', 
    x: 520, y: 80, width: 200, height: 150, 
    description: 'Executive Suite Room 101. Office of Abebe Bikila. Features a modern wooden desk, meeting area, and panoramic view.',
    imageUrl: 'https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=800&h=500&fit=crop'
  },
  { 
    id: 'g1', 
    name: 'Main Gate', 
    type: 'gate', 
    x: 340, y: 550, width: 100, height: 30, 
    description: 'Gate A Security Entrance. Features solid stone pillars and heavy iron gates to ensure compound security.',
    imageUrl: 'https://images.unsplash.com/photo-1517404215738-15263e9f9178?w=800&h=500&fit=crop'
  },
  { 
    id: 'f1', 
    name: 'Waiting Pavilion', 
    type: 'facility', 
    x: 200, y: 240, width: 280, height: 100, 
    description: 'Modern wooden pavilion structure providing a comfortable outdoor waiting area for residents.',
    imageUrl: 'https://images.unsplash.com/photo-1549294413-26f195200c16?w=800&h=500&fit=crop'
  },
  { 
    id: 'f2', 
    name: 'Community Garden', 
    type: 'facility', 
    x: 520, y: 280, width: 240, height: 200, 
    description: 'Urban gardening project with raised planting beds. A green oasis for community relaxation.',
    imageUrl: 'https://images.unsplash.com/photo-1591857177580-dc82b9ac4e17?w=800&h=500&fit=crop'
  },
  { 
    id: 'f3', 
    name: 'Parking Area', 
    type: 'facility', 
    x: 40, y: 500, width: 200, height: 80, 
    description: 'Spacious asphalt parking area for staff and visitors.',
    imageUrl: 'https://images.unsplash.com/photo-1506521781263-d8422e82f27a?w=800&h=500&fit=crop'
  },
  { 
    id: 'f4', 
    name: 'Public Toilets', 
    type: 'facility', 
    x: 680, y: 520, width: 80, height: 60, 
    description: 'Clean, modern restroom facility with contemporary tiling and high-quality fixtures.',
    imageUrl: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=800&h=500&fit=crop'
  },
];

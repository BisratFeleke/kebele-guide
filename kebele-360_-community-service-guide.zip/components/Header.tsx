
import React from 'react';
import { View } from '../types';

interface HeaderProps {
  currentView: View;
  setCurrentView: (view: View) => void;
}

const Header: React.FC<HeaderProps> = ({ currentView, setCurrentView }) => {
  return (
    <header className="bg-white border-b-4 ethiopian-border shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div 
          className="flex items-center space-x-3 cursor-pointer group"
          onClick={() => setCurrentView('home')}
        >
          {/* Contemporary Abstract Logo */}
          <div className="relative w-10 h-10">
            <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-sm transition-transform duration-500 group-hover:rotate-180">
              {/* Outer Glow Circle */}
              <circle cx="50" cy="50" r="48" fill="none" stroke="#f3f4f6" strokeWidth="2" />
              
              {/* 360 Degree Segmented Path (Contemporary interpretation) */}
              <path d="M50 5 A45 45 0 0 1 95 50" fill="none" stroke="#009739" strokeWidth="8" strokeLinecap="round" />
              <path d="M95 50 A45 45 0 0 1 50 95" fill="none" stroke="#FEDD00" strokeWidth="8" strokeLinecap="round" />
              <path d="M50 95 A45 45 0 0 1 5 50" fill="none" stroke="#EF3340" strokeWidth="8" strokeLinecap="round" />
              <path d="M5 50 A45 45 0 0 1 50 5" fill="none" stroke="#4285F4" strokeWidth="8" strokeLinecap="round" strokeDasharray="5 5" />
              
              {/* Center Dot */}
              <circle cx="50" cy="50" r="10" fill="#374151" />
            </svg>
          </div>
          <div className="flex flex-col">
            <span className="text-xl font-black text-gray-800 leading-none tracking-tight">
              KEBELE<span className="text-green-600">360</span>
            </span>
            <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mt-1">Smart Community Hub</span>
          </div>
        </div>

        <nav className="hidden md:flex space-x-1">
          {[
            { id: 'home', label: 'Dashboard' },
            { id: 'services', label: 'Services' },
            { id: 'map', label: 'Facility Map' },
            { id: 'chat', label: 'AI Support' }
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setCurrentView(item.id as View)}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                currentView === item.id 
                  ? 'bg-gray-100 text-green-700 shadow-inner' 
                  : 'text-gray-500 hover:text-gray-800 hover:bg-gray-50'
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center space-x-3">
          <button className="p-2 text-gray-400 hover:text-gray-600 relative">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path></svg>
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
          </button>
          <div className="w-9 h-9 rounded-full bg-gray-200 border-2 border-white overflow-hidden shadow-sm">
            <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop" alt="Profile" className="w-full h-full object-cover" />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;

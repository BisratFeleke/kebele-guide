
import React, { useState } from 'react';
import { KebeleService } from '../types';
import { SERVICES } from '../constants';

interface ServiceListProps {
  onSelect: (service: KebeleService) => void;
}

const ServiceList: React.FC<ServiceListProps> = ({ onSelect }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredServices = SERVICES.filter(s => 
    s.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-gray-100 flex items-center space-x-3">
        <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
        <input 
          type="text" 
          placeholder="Search for a service (e.g. ID card, birth cert...)" 
          className="bg-transparent border-none outline-none flex-1 text-gray-700 font-medium"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredServices.map(service => (
          <div 
            key={service.id}
            onClick={() => onSelect(service)}
            className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 hover:shadow-md hover:border-green-300 transition-all cursor-pointer group flex flex-col justify-between"
          >
            <div>
              <div className="flex justify-between items-start mb-4">
                <h3 className="text-xl font-bold text-gray-900 group-hover:text-green-700 transition-colors">
                  {service.title}
                </h3>
                <span className="px-2 py-1 bg-gray-50 text-[10px] font-bold text-gray-400 rounded uppercase tracking-wider">
                  {service.processingTime.includes('Day') ? 'Standard' : 'Fast'}
                </span>
              </div>
              <p className="text-gray-500 text-sm mb-6 line-clamp-2">
                {service.description}
              </p>
            </div>
            
            <div className="flex items-center justify-between border-t border-gray-50 pt-4">
              <div className="flex -space-x-2">
                {[1, 2, 3].map(i => (
                  <div key={i} className="w-6 h-6 rounded-full border-2 border-white bg-gray-200 overflow-hidden">
                    <img src={`https://picsum.photos/seed/avatar${i}/100`} alt="Agent" />
                  </div>
                ))}
                <span className="pl-3 text-xs font-medium text-gray-400 self-center">+ 2 Staff</span>
              </div>
              <button className="text-green-600 font-bold text-sm flex items-center group-hover:translate-x-1 transition-transform">
                Get Requirements
                <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredServices.length === 0 && (
        <div className="text-center py-20 bg-gray-50 rounded-3xl border-2 border-dashed border-gray-200">
           <p className="text-gray-400">No services found matching your search.</p>
           <button 
            onClick={() => setSearchTerm('')}
            className="mt-4 text-green-600 font-bold underline"
           >
             Clear search
           </button>
        </div>
      )}
    </div>
  );
};

export default ServiceList;


import React from 'react';
import { KebeleService } from '../types';
import { STAFF_LIST, MAP_LOCATIONS } from '../constants';

interface ServiceDetailProps {
  service: KebeleService;
  onBack: () => void;
}

const ServiceDetail: React.FC<ServiceDetailProps> = ({ service, onBack }) => {
  const getStaffById = (id: string) => STAFF_LIST.find(s => s.id === id);
  const getOfficeById = (id: string) => MAP_LOCATIONS.find(l => l.id === id);

  return (
    <div className="space-y-6">
      <button 
        onClick={onBack}
        className="group flex items-center text-sm font-bold text-gray-400 hover:text-gray-800 transition-colors"
      >
        <div className="w-8 h-8 rounded-full border border-gray-100 flex items-center justify-center mr-2 group-hover:bg-gray-100 transition-colors">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7"></path></svg>
        </div>
        Back to Directory
      </button>

      <div className="bg-white rounded-[2rem] shadow-xl border border-gray-100 overflow-hidden">
        <div className="bg-gradient-to-br from-[#009739] via-[#FEDD00] to-[#EF3340] p-[2px]">
          <div className="bg-white p-8 md:p-12">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-8">
              <div>
                <span className="inline-block px-3 py-1 bg-green-50 text-green-700 text-[10px] font-black rounded-full uppercase tracking-tighter mb-3">Service Profile</span>
                <h2 className="text-4xl font-black text-gray-900 tracking-tight">{service.title}</h2>
                <p className="text-gray-500 mt-4 text-lg leading-relaxed max-w-3xl">{service.description}</p>
              </div>
              <div className="flex flex-col items-end">
                <div className="text-right">
                   <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Processing</p>
                   <p className="text-2xl font-black text-green-600">{service.processingTime}</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
              <div className="lg:col-span-1 space-y-10">
                <section>
                  <h3 className="text-xs font-black text-gray-800 uppercase tracking-[0.2em] mb-6 border-b border-gray-100 pb-2">Document Checklist</h3>
                  <ul className="space-y-4">
                    {service.requiredDocuments.map((doc, idx) => (
                      <li key={idx} className="flex items-start group">
                        <div className="mt-1 w-6 h-6 rounded-full bg-gray-50 border border-gray-200 flex items-center justify-center mr-4 flex-shrink-0 group-hover:bg-green-50 group-hover:border-green-200 transition-colors">
                          <svg className="w-3 h-3 text-gray-400 group-hover:text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path></svg>
                        </div>
                        <span className="text-gray-700 text-sm font-semibold">{doc}</span>
                      </li>
                    ))}
                  </ul>
                </section>

                <section className="bg-gray-50/50 p-6 rounded-3xl border border-gray-100">
                   <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4">Availability</h4>
                   <div className="flex items-center space-x-3 mb-4">
                      <div className="w-10 h-10 bg-white rounded-xl shadow-sm flex items-center justify-center text-yellow-500">
                         <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                      </div>
                      <div>
                        <p className="text-xs font-bold text-gray-800">{service.availableDays}</p>
                        <p className="text-[10px] text-gray-400">Public Holidays Excluded</p>
                      </div>
                   </div>
                </section>
              </div>

              <div className="lg:col-span-2 space-y-8">
                <h3 className="text-xs font-black text-gray-800 uppercase tracking-[0.2em] mb-6 border-b border-gray-100 pb-2">Workflow & Personnel</h3>
                <div className="space-y-6">
                  {service.steps.map((step, idx) => {
                    const staff = getStaffById(step.staffId);
                    const office = getOfficeById(step.officeId);
                    return (
                      <div key={idx} className="flex gap-6 group">
                        <div className="flex flex-col items-center">
                          <div className="w-10 h-10 rounded-2xl bg-gray-900 text-white flex items-center justify-center font-black text-xs shadow-lg group-hover:bg-green-600 transition-colors">
                            {idx + 1}
                          </div>
                          {idx !== service.steps.length - 1 && (
                            <div className="w-[2px] h-full bg-gray-100 my-2"></div>
                          )}
                        </div>
                        <div className="flex-1 pb-8">
                          <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm hover:shadow-md transition-all border-l-4 border-l-gray-200 group-hover:border-l-green-500">
                            <p className="text-gray-900 font-bold text-lg mb-6">{step.description}</p>
                            
                            <div className="flex flex-wrap items-center gap-6">
                              <div className="flex items-center space-x-4 bg-gray-50 px-4 py-2 rounded-2xl">
                                <img src={staff?.avatar} alt={staff?.name} className="w-10 h-10 rounded-full object-cover border-2 border-white shadow-sm" />
                                <div>
                                  <p className="text-xs font-black text-gray-900">{staff?.name}</p>
                                  <p className="text-[10px] text-gray-500 font-bold uppercase">{staff?.role}</p>
                                </div>
                              </div>

                              <div className="flex items-center space-x-2">
                                 <div className="w-8 h-8 rounded-full bg-blue-50 flex items-center justify-center text-blue-600">
                                   <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg>
                                 </div>
                                 <span className="text-xs font-black text-gray-700">{office?.name}</span>
                              </div>

                              {step.paymentAmount !== undefined && (
                                <div className={`flex items-center space-x-2 px-4 py-2 rounded-2xl ${step.paymentAmount > 0 ? 'bg-yellow-50 text-yellow-700' : 'bg-green-50 text-green-700'}`}>
                                   <span className="text-xs font-black">
                                     {step.paymentAmount === 0 ? 'NO FEE' : `${step.paymentAmount} ETB`}
                                   </span>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServiceDetail;


import React, { useState, useMemo } from 'react';
import { MAP_LOCATIONS } from '../constants';
import { MapLocation } from '../types';

type MapMode = 'map' | 'satellite';

const InteractiveMap: React.FC = () => {
  const [selectedLocation, setSelectedLocation] = useState<MapLocation | null>(null);
  const [mapMode, setMapMode] = useState<MapMode>('map');
  const [navFrom, setNavFrom] = useState<string>('');
  const [navTo, setNavTo] = useState<string>('');
  const [isNavigating, setIsNavigating] = useState(false);

  // Helper for Google Maps marker colors
  const getMarkerColor = (type: string) => {
    switch (type) {
      case 'office': return '#4285F4'; // Google Blue
      case 'facility': return '#34A853'; // Google Green
      case 'gate': return '#EA4335'; // Google Red
      default: return '#70757a'; // Gray
    }
  };

  // Simple coordinate-based pathfinding
  const navigationPath = useMemo(() => {
    if (!navFrom || !navTo) return null;
    const fromLoc = MAP_LOCATIONS.find(l => l.id === navFrom);
    const toLoc = MAP_LOCATIONS.find(l => l.id === navTo);
    if (!fromLoc || !toLoc) return null;

    const startX = fromLoc.x + fromLoc.width / 2;
    const startY = fromLoc.y + fromLoc.height / 2;
    const endX = toLoc.x + toLoc.width / 2;
    const endY = toLoc.y + toLoc.height / 2;

    const h1X = 400, h1Y = 460; // Main Junction
    return `${startX},${startY} ${startX},${h1Y} ${endX},${h1Y} ${endX},${endY}`;
  }, [navFrom, navTo]);

  const handleStartDirections = (targetId: string) => {
    setNavFrom('g1'); 
    setNavTo(targetId);
    setIsNavigating(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Kebele Navigation</h2>
          <p className="text-gray-500 text-sm">Real-time facility guidance and indoor routing.</p>
        </div>
        <div className="flex bg-white p-1 rounded-xl shadow-sm border border-gray-100 mt-4 md:mt-0">
          <button 
            onClick={() => setMapMode('map')}
            className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-colors ${mapMode === 'map' ? 'bg-blue-50 text-blue-600' : 'text-gray-400 hover:text-gray-600'}`}
          >
            Map
          </button>
          <button 
            onClick={() => setMapMode('satellite')}
            className={`px-4 py-1.5 text-xs font-bold rounded-lg transition-colors ${mapMode === 'satellite' ? 'bg-blue-50 text-blue-600' : 'text-gray-400 hover:text-gray-600'}`}
          >
            Satellite
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3 relative">
          {/* Navigation Overlay Card */}
          <div className="absolute top-4 left-4 z-20 w-72 bg-white rounded-2xl shadow-2xl border border-gray-100 p-4">
             <div className="space-y-3">
                <div className="flex items-center space-x-3">
                   <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                   <select 
                     value={navFrom}
                     onChange={(e) => setNavFrom(e.target.value)}
                     className="flex-1 bg-gray-50 border-none text-xs font-bold p-2 rounded-lg outline-none focus:ring-1 focus:ring-blue-400"
                   >
                     <option value="">Starting position...</option>
                     {MAP_LOCATIONS.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}
                   </select>
                </div>
                <div className="flex items-center space-x-3">
                   <div className="w-2 h-2 rounded-full bg-red-500"></div>
                   <select 
                     value={navTo}
                     onChange={(e) => setNavTo(e.target.value)}
                     className="flex-1 bg-gray-50 border-none text-xs font-bold p-2 rounded-lg outline-none focus:ring-1 focus:ring-blue-400"
                   >
                     <option value="">Final destination...</option>
                     {MAP_LOCATIONS.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}
                   </select>
                </div>
                {navFrom && navTo && (
                  <div className="pt-2">
                    <button 
                      onClick={() => setIsNavigating(true)}
                      className="w-full bg-blue-600 text-white py-2 rounded-lg text-xs font-black shadow-lg hover:bg-blue-700 transition-transform active:scale-95"
                    >
                      Start Navigation
                    </button>
                    <button 
                      onClick={() => { setIsNavigating(false); setNavFrom(''); setNavTo(''); }}
                      className="w-full text-gray-400 text-[10px] mt-2 font-bold hover:text-gray-600"
                    >
                      Clear Route
                    </button>
                  </div>
                )}
             </div>
          </div>

          <div className={`rounded-3xl border border-gray-200 shadow-lg overflow-hidden relative ${mapMode === 'satellite' ? 'bg-[#1a1a1a]' : 'bg-[#f8f9fa]'}`}>
            <div className="overflow-auto scrollbar-hide">
              <svg 
                viewBox="0 0 800 600" 
                className={`w-full h-auto min-w-[700px] transition-all duration-500 ${mapMode === 'satellite' ? 'bg-[#0b0c10]' : 'bg-[#e8eaed]'}`}
                xmlns="http://www.w3.org/2000/svg"
              >
                {/* Patterns and Textures */}
                <defs>
                  <pattern id="grass-sat" width="100" height="100" patternUnits="userSpaceOnUse">
                    <rect width="100" height="100" fill="#1b2b1a" />
                    <circle cx="20" cy="20" r="15" fill="#2d3d25" opacity="0.3" />
                    <circle cx="70" cy="60" r="25" fill="#1e2b18" opacity="0.2" />
                    <path d="M0,0 L100,100 M100,0 L0,100" stroke="#121811" strokeWidth="0.5" opacity="0.1" />
                  </pattern>
                  <pattern id="grid-pattern" width="40" height="40" patternUnits="userSpaceOnUse">
                    <path d="M 40 0 L 0 0 0 40" fill="none" stroke={mapMode === 'satellite' ? '#222' : '#dadce0'} strokeWidth="0.5"/>
                  </pattern>
                </defs>

                <rect width="800" height="600" fill="url(#grid-pattern)" />

                {/* Satellite Specific Visuals */}
                {mapMode === 'satellite' && (
                  <>
                    <rect x="10" y="10" width="780" height="580" fill="url(#grass-sat)" rx="15" />
                    {/* Asphalt Roads for Satellite */}
                    <path d="M 0 460 L 800 460" stroke="#333" strokeWidth="50" strokeLinecap="square" />
                    <path d="M 400 460 L 400 0" stroke="#333" strokeWidth="50" strokeLinecap="square" />
                    <path d="M 0 460 L 800 460" stroke="#444" strokeWidth="2" strokeDasharray="10 20" />
                    <path d="M 400 460 L 400 0" stroke="#444" strokeWidth="2" strokeDasharray="10 20" />
                  </>
                )}

                {/* Vector Map Roads */}
                {mapMode === 'map' && (
                  <>
                    <path d="M 0 460 L 800 460" stroke="white" strokeWidth="45" strokeLinecap="round" />
                    <path d="M 400 460 L 400 0" stroke="white" strokeWidth="45" strokeLinecap="round" />
                  </>
                )}

                {/* Locations Rendering */}
                {MAP_LOCATIONS.map((loc) => {
                  const isSelected = selectedLocation?.id === loc.id;
                  const isDestination = navTo === loc.id;
                  const isSource = navFrom === loc.id;
                  const color = getMarkerColor(loc.type);
                  
                  return (
                    <g 
                      key={loc.id} 
                      className="cursor-pointer group"
                      onClick={() => setSelectedLocation(loc)}
                    >
                      {/* Building base */}
                      <rect 
                        x={loc.x} 
                        y={loc.y} 
                        width={loc.width} 
                        height={loc.height} 
                        rx="4"
                        fill={mapMode === 'satellite' 
                          ? (loc.type === 'office' ? '#2c2c2e' : loc.type === 'facility' ? '#141e14' : '#331a1a') 
                          : (loc.type === 'office' ? '#e3f2fd' : loc.type === 'facility' ? '#e8f5e9' : '#fce4ec')
                        }
                        stroke={isSelected ? color : (mapMode === 'satellite' ? '#444' : '#bdc1c6')}
                        strokeWidth={isSelected ? 4 : 1}
                        className="transition-all"
                      />

                      {/* Pins */}
                      <g transform={`translate(${loc.x + loc.width/2}, ${loc.y + loc.height/2})`}>
                        <path 
                          d="M0 -15 C-5 -15 -10 -10 -10 -5 C-10 2 0 10 0 10 C 0 10 10 2 10 -5 C10 -10 5 -15 0 -15 Z" 
                          fill={isDestination ? '#EA4335' : (isSource ? '#4285F4' : color)} 
                          className="drop-shadow-lg"
                        />
                        <circle cx="0" cy="-5" r="3" fill="white" />
                        
                        <text 
                          y="24" 
                          textAnchor="middle" 
                          className={`text-[10px] font-black tracking-tighter ${mapMode === 'satellite' ? 'fill-gray-400' : 'fill-gray-700'} ${isSelected ? 'scale-110' : ''}`}
                        >
                          {loc.name}
                        </text>
                      </g>
                    </g>
                  );
                })}

                {/* Navigation Solid Red Line (like Google Maps) */}
                {isNavigating && navigationPath && (
                  <g>
                    {/* Shadow for the line */}
                    <polyline 
                      points={navigationPath} 
                      fill="none" 
                      stroke="black" 
                      strokeWidth="8" 
                      strokeLinecap="round" 
                      strokeLinejoin="round"
                      opacity="0.1"
                    />
                    {/* Main Red Line */}
                    <polyline 
                      points={navigationPath} 
                      fill="none" 
                      stroke="#EF3340" 
                      strokeWidth="6" 
                      strokeLinecap="round" 
                      strokeLinejoin="round"
                      className="transition-all"
                    />
                    {/* Animated white dashes for movement indicator */}
                    <polyline 
                      points={navigationPath} 
                      fill="none" 
                      stroke="white" 
                      strokeWidth="2" 
                      strokeLinecap="round" 
                      strokeLinejoin="round"
                      strokeDasharray="8 20"
                      className="animate-flow"
                    />
                  </g>
                )}
              </svg>
            </div>
          </div>
        </div>

        <div className="lg:col-span-1">
          {selectedLocation ? (
            <div className="bg-white h-full rounded-3xl border border-gray-100 shadow-xl overflow-hidden flex flex-col animate-fadeIn">
              <div className="h-48 bg-gray-200 relative">
                 <img 
                   src={selectedLocation.imageUrl || `https://images.unsplash.com/photo-1577495508048-b635879837f1?w=400&h=300&fit=crop`} 
                   alt={selectedLocation.name} 
                   className="w-full h-full object-cover"
                 />
                 <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                 <h3 className="absolute bottom-4 left-6 text-white text-xl font-black">{selectedLocation.name}</h3>
                 <button 
                  onClick={() => setSelectedLocation(null)}
                  className="absolute top-4 right-4 w-8 h-8 bg-black/30 text-white rounded-full flex items-center justify-center hover:bg-black/50 backdrop-blur-sm"
                 >✕</button>
              </div>
              <div className="p-6 flex-1 overflow-y-auto">
                <div className="flex items-center justify-between mb-4">
                  <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                    selectedLocation.type === 'office' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700'
                  }`}>
                    {selectedLocation.type}
                  </span>
                  <div className="flex items-center text-yellow-500 bg-yellow-50 px-2 py-1 rounded-lg">
                    <svg className="w-3 h-3 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/></svg>
                    <span className="text-xs font-black ml-1">4.8</span>
                  </div>
                </div>

                <div className="space-y-6">
                  <section>
                    <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Location View</h4>
                    <p className="text-gray-600 text-sm leading-relaxed font-medium">{selectedLocation.description}</p>
                  </section>

                  <section className="bg-blue-50/50 p-4 rounded-2xl border border-blue-100">
                    <h4 className="text-[10px] font-black text-blue-400 uppercase tracking-[0.2em] mb-3">Facility Status</h4>
                    <div className="space-y-3">
                       <div className="flex items-center text-xs font-bold text-gray-600">
                          <span className="w-2 h-2 bg-green-500 rounded-full mr-3"></span> Open Now · 08:30 - 17:30
                       </div>
                       <div className="flex items-center text-xs font-bold text-gray-600">
                          <span className="w-2 h-2 bg-blue-500 rounded-full mr-3"></span> High Frequency Hours (10:00 - 14:00)
                       </div>
                    </div>
                  </section>
                </div>
              </div>
              
              <div className="p-4 bg-gray-50 border-t border-gray-100 grid grid-cols-1 gap-3">
                 <button 
                  onClick={() => handleStartDirections(selectedLocation.id)}
                  className="bg-blue-600 text-white py-4 rounded-2xl font-black text-sm shadow-xl hover:bg-blue-700 flex items-center justify-center transition-all active:scale-[0.98]"
                 >
                    <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2L4.5 20.29l.71.71L12 18l6.79 3 .71-.71z"/></svg>
                    Start From My Location
                 </button>
              </div>
            </div>
          ) : (
            <div className="bg-white border border-gray-200 rounded-3xl p-8 text-center h-full flex flex-col items-center justify-center shadow-sm">
              <div className="w-24 h-24 bg-blue-50 rounded-full mb-6 flex items-center justify-center text-blue-600">
                 <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
              </div>
              <h4 className="text-xl font-black text-gray-800 mb-2 tracking-tight">Navigate Compound</h4>
              <p className="text-gray-400 text-sm max-w-[240px] mx-auto font-medium">Use the From/To panel to find your way or select a marker to see its street view.</p>
            </div>
          )}
        </div>
      </div>
      <style>{`
        @keyframes flow {
          to {
            stroke-dashoffset: -28;
          }
        }
        .animate-flow {
          animation: flow 1s linear infinite;
        }
      `}</style>
    </div>
  );
};

export default InteractiveMap;

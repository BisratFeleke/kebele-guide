
import React, { useState, useMemo } from 'react';
import Header from './components/Header';
import ServiceList from './components/ServiceList';
import ServiceDetail from './components/ServiceDetail';
import InteractiveMap from './components/InteractiveMap';
import ChatBot from './components/ChatBot';
import { KebeleService, View } from './types';
import { SERVICES } from './constants';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<View>('home');
  const [selectedService, setSelectedService] = useState<KebeleService | null>(null);

  const handleServiceSelect = (service: KebeleService) => {
    setSelectedService(service);
    setCurrentView('services');
  };

  const clearService = () => {
    setSelectedService(null);
  };

  return (
    <div className="min-h-screen flex flex-col pb-20 md:pb-0">
      <Header currentView={currentView} setCurrentView={setCurrentView} />

      <main className="flex-1 container mx-auto p-4 max-w-5xl">
        {currentView === 'home' && (
          <div className="space-y-8 animate-fadeIn">
            <section className="text-center py-10">
              <h1 className="text-4xl font-extrabold text-gray-900 mb-4 tracking-tight">
                Welcome to <span className="text-green-600">Kebele 360</span>
              </h1>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                Your digital companion for efficient public services. Find requirements, follow workflows, and navigate our facility with ease.
              </p>
            </section>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div 
                onClick={() => setCurrentView('services')}
                className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:border-yellow-400 cursor-pointer transition-all group"
              >
                <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <svg className="w-6 h-6 text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                </div>
                <h3 className="text-xl font-bold mb-2">Service Directory</h3>
                <p className="text-gray-500 text-sm">List of all IDs, certificates, and legal services available.</p>
              </div>

              <div 
                onClick={() => setCurrentView('map')}
                className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:border-green-400 cursor-pointer transition-all group"
              >
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-1.447-.894L15 7m0 10V7m0 0l-6-3"></path></svg>
                </div>
                <h3 className="text-xl font-bold mb-2">Navigate Compound</h3>
                <p className="text-gray-500 text-sm">Interactive map showing offices, waiting areas, and facility exits.</p>
              </div>

              <div 
                onClick={() => setCurrentView('chat')}
                className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:border-red-400 cursor-pointer transition-all group"
              >
                <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <svg className="w-6 h-6 text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"></path></svg>
                </div>
                <h3 className="text-xl font-bold mb-2">AI Assistant</h3>
                <p className="text-gray-500 text-sm">Ask questions about our services and get instant guidance.</p>
              </div>
            </div>

            <section className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm mt-8">
               <h2 className="text-2xl font-bold mb-6 flex items-center">
                  <span className="w-2 h-8 bg-yellow-400 rounded-full mr-3"></span>
                  Common Services
               </h2>
               <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {SERVICES.slice(0, 4).map(s => (
                    <button 
                      key={s.id}
                      onClick={() => handleServiceSelect(s)}
                      className="text-left p-4 border border-gray-100 rounded-xl hover:bg-gray-50 flex justify-between items-center transition-colors"
                    >
                      <div>
                        <span className="font-semibold block">{s.title}</span>
                        <span className="text-xs text-gray-400">{s.processingTime} processing</span>
                      </div>
                      <svg className="w-5 h-5 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path></svg>
                    </button>
                  ))}
               </div>
            </section>
          </div>
        )}

        {currentView === 'services' && (
          <div className="animate-slideUp">
            {selectedService ? (
              <ServiceDetail service={selectedService} onBack={clearService} />
            ) : (
              <ServiceList onSelect={handleServiceSelect} />
            )}
          </div>
        )}

        {currentView === 'map' && <InteractiveMap />}

        {currentView === 'chat' && <ChatBot />}
      </main>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-6 py-3 flex justify-between items-center z-50">
        <button onClick={() => setCurrentView('home')} className={`flex flex-col items-center ${currentView === 'home' ? 'text-green-600' : 'text-gray-400'}`}>
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
          <span className="text-[10px] mt-1 font-medium">Home</span>
        </button>
        <button onClick={() => setCurrentView('services')} className={`flex flex-col items-center ${currentView === 'services' ? 'text-green-600' : 'text-gray-400'}`}>
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path></svg>
          <span className="text-[10px] mt-1 font-medium">Services</span>
        </button>
        <button onClick={() => setCurrentView('map')} className={`flex flex-col items-center ${currentView === 'map' ? 'text-green-600' : 'text-gray-400'}`}>
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
          <span className="text-[10px] mt-1 font-medium">Map</span>
        </button>
        <button onClick={() => setCurrentView('chat')} className={`flex flex-col items-center ${currentView === 'chat' ? 'text-green-600' : 'text-gray-400'}`}>
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"></path></svg>
          <span className="text-[10px] mt-1 font-medium">Assistant</span>
        </button>
      </nav>
    </div>
  );
};

export default App;

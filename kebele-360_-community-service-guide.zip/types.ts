
export interface Staff {
  id: string;
  name: string;
  role: string;
  avatar: string;
  officeNumber: string;
}

export interface ServiceStep {
  order: number;
  description: string;
  officeId: string;
  staffId: string;
  paymentAmount?: number;
}

export interface KebeleService {
  id: string;
  title: string;
  description: string;
  requiredDocuments: string[];
  processingTime: string;
  availableDays: string;
  steps: ServiceStep[];
}

export interface MapLocation {
  id: string;
  name: string;
  type: 'office' | 'facility' | 'gate' | 'other';
  x: number;
  y: number;
  width: number;
  height: number;
  description: string;
  imageUrl?: string;
}

export type View = 'home' | 'services' | 'map' | 'chat';
